﻿using GroceryItemsPractice.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GroceryItemsPractice.View
{
	/// <summary>
	/// Interaction logic for GroceryItemView.xaml
	/// </summary>
	public partial class GroceryItemView : Window
	{
		public GroceryItemView(MainViewModel mainViewModel)
		{
			InitializeComponent();
			this.DataContext = new GroceryItemViewModel(this,mainViewModel);
		}

		public GroceryItemView(MainViewModel mainViewModel, GroceryItemDetailViewModel selectedItem)
		{
			InitializeComponent();
			this.DataContext = new GroceryItemViewModel(this, mainViewModel, selectedItem);
		}
	}
}
